import json, runpy, sys
from pathlib import Path
compute = runpy.run_path(str(Path(sys.argv[1])/'engine.py'))['compute']
Path(sys.argv[2]).write_text(json.dumps({'correct':compute(16)==32}))
