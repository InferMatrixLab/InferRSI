import json, sys
from pathlib import Path
config = json.loads((Path(sys.argv[1])/'config.json').read_text())
Path(sys.argv[2]).write_text(json.dumps({'metric':config['metric']}))
