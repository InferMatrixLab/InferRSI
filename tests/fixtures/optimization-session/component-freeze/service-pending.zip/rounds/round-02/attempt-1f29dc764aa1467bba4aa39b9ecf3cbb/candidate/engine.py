CONFIG = {'version': 'second-pass', 'a': 90, 'b': 100, 'quality': 1}
