CONFIG = {'version': 'first-pass', 'a': 95, 'b': 100, 'quality': 1}
