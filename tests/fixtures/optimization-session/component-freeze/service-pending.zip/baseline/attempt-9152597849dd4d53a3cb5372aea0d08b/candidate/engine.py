CONFIG = {'version': 'baseline', 'a': 100, 'b': 100, 'quality': 1}
