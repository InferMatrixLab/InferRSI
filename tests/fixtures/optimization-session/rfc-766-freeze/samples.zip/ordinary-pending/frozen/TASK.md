Synthetic protocol control
