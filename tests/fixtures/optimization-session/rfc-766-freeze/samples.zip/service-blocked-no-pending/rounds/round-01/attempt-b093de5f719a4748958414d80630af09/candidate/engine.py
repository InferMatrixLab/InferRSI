CONFIG = {'version': 'missing-metric', 'a': 90, 'b': 100, 'quality': 1, 'missing_metric': True}
