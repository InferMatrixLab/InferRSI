CONFIG = {'version': 'interrupted', 'a': 110, 'b': 100, 'quality': 1}
