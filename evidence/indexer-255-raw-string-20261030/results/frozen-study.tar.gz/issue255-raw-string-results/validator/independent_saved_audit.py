"""Supplemental retained-output audit: no scorer, retrieval or experiment execution."""
import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def load(p):
    return json.loads((root / p).read_bytes())
def sha(p):
    return hashlib.sha256((root / p).read_bytes()).hexdigest()
freeze = load('plan/freeze.json')
assert sha('validator/compare.py') == freeze['runner_sha256']
for p, h in freeze['inputs'].items():
    assert sha(p) == h
start = load('results/study-start.json')
assert start['freeze_sha256'] == sha('plan/freeze.json')
assert start['static_review_sha256'] == sha('plan/static-review.json')
sources = load('results/source-before.json')
assert sources == load('results/source-after.json')
fixture = load('validator/synthetic-lexical-contract-v1.json')
a = load('results/baseline.stdout.json')
b = load('results/candidate.stdout.json')
positive, false_positive, nonstring = 0, 0, 0
for case in fixture['cases']:
    cid = case['id']
    old, new = a['scalar'][cid], b['scalar'][cid]
    expected = {k: sorted(v) for k, v in case['expected_per_field_matches'].items()}
    assert new['matches'] == expected
    assert new['tokens'] == sorted(case['expected_distinct_tokens'])
    assert new['score'] == case['expected_score']
    assert new['per_field_scores'] == {k:len(v)*case['fields'][k]['weight'] for k,v in expected.items()}
    for field, matches in expected.items():
        positive += len(matches)
        false_positive += len(set(old['matches'][field])-set(matches))
        assert not set(matches)-set(old['matches'][field])
        if not isinstance(case['fields'][field]['value'],str):
            nonstring += 1
            assert old['matches'][field] == new['matches'][field]
            assert old['per_field_scores'][field] == new['per_field_scores'][field]
for f in fixture['ranking_fixtures']:
    r = b['rankings'][f['id']]
    assert r['full_order'] == f['expected_order']
    assert r['positive_order'] == f['expected_positive_order']
    assert r['omissions'] == []
    for record in f['records']:
        key = record['qualifiedid']
        assert r['scores'][key] == record['expected_score']
        assert r['fields'][key]['matches'] == {k:sorted(v) for k,v in record['expected_per_field_matches'].items()}
        assert r['fields'][key]['score'] == record['expected_score']
assert a['default_scalar'] == b['default_scalar']
assert a['compatibility_default'] == b['compatibility_default']
for name, output in b['compatibility_raw']['outputs'].items():
    v = copy.deepcopy(output)
    if 'selection' in v:
        v['selection']['method'] = 'weighted-lexical-v1'
    assert v == a['compatibility_default']['outputs'][name], name
for group in [a['compatibility_default'], b['compatibility_default'], b['compatibility_raw']]:
    assert all(group['checks'].values())
    for name, output in group['outputs'].items():
        if 'contexts' not in output:
            continue
        total = 0
        for context in output['contexts']:
            size = 0
            for resource in context['resources']:
                data = resource['content'].encode()
                assert hashlib.sha256(data).hexdigest() == resource['sha256']
                size += len(data)
            assert size == context['content_bytes']
            total += size
            if name.startswith('context_') and name != 'context_insufficient':
                suffixes = {x['path'].split('/')[-1] for x in context['resources']}
                assert {'SKILL.md','refs.md','LICENSE'} <= suffixes
        assert total == output['context_bytes'] <= output['context_budget']['max_bytes']
for arm, output in [('baseline',a),('candidate',b)]:
    for stage in ['module_provenance_before_scoring','module_provenance_after_scoring']:
        assert output[stage]
        for name, info in output[stage].items():
            assert info['sha256'] == sources[arm]['source_sha256'][info['path']]
    assert not (root/f'results/{arm}.stderr.txt').read_bytes()
    demo = output['fixed_real_corpus_cli_diagnostic']
    assert demo['exit_code'] == 0
    body = demo['output']
    total = 0
    for context in body['contexts']:
        view = next(i for i in body['items'] if i['ref']==context['ref'])
        assert view['revision'] == context['revision']
        size = 0
        for resource in context['resources']:
            data = resource['content'].encode()
            h = hashlib.sha256(data).hexdigest()
            assert h == resource['sha256'] == view['resources'][resource['path']]
            assert h == sources[arm]['source_sha256']['src/inferrsi/'+resource['path']]
            size += len(data)
        assert size == context['content_bytes']
        total += size
    assert total == body['context_bytes'] <= 65536
assert (positive,false_positive,nonstring)==(26,5,6)
verdict=load('results/verdict.json')
assert verdict['verdict']=='PASS' and verdict['failures']==[]
assert verdict['retained_positive_field_token_controls']==positive
assert sum(len(x['tokens']) for x in verdict['corrected_false_positive_contributions'])==false_positive
receipt={
 'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
 'decision':'PASS_WITHIN_FROZEN_SYNTHETIC_CONTRACT_SCOPE',
 'baseline_sha':freeze['baseline_sha'],'candidate_sha':freeze['candidate_sha'],
 'runner_sha256':freeze['runner_sha256'],'fixtures_sha256':sha('validator/synthetic-lexical-contract-v1.json'),
 'method':'Independent retained-output label/arithmetic/resource/hash/source/module audit; no scorer/retrieval/candidate execution.',
 'scalar_cases':14,'ranking_fixtures':2,'phantom_field_token_contributions_removed':5,
 'genuine_field_token_controls_retained':26,'nonstring_controls_unchanged':6,
 'compatibility_requests':len(a['compatibility_default']['outputs']),
 'source_and_module_identity_verified':True,'default_parity_verified':True,
 'context_hash_bytes_required_core_ref_license_and_budget_verified':True,
 'fixed_cli_demo':'Source resource hashes and bytes verified; interface-only, no semantic relevance or latency inference.',
 'limits':['Synthetic adversarial lexical contract, not general task accuracy or user distribution.','No default-method promotion or #255 closure implied.','Historical failures remain distinct; old heldout unused.']}
(root/'results/independent-postrun-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
