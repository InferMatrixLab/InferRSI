"""Render retained comparison outputs. Does not import or execute either scorer."""
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("results", type=Path)
args = parser.parse_args()
base = json.loads((args.results / "baseline.stdout.json").read_text())
raw = json.loads((args.results / "candidate.stdout.json").read_text())
print("SYNTHETIC CONTRACT DEMO — not general retrieval accuracy")
print("Cue: n t; fields retain substring matching and weights 4/3/2/1.")
print("A title with actual newline+tab has neither literal n nor literal t.")
print("A title with literal backslash-n/backslash-t contains both letters.\n")
name = "escape_weighted_ties"
print("Record                         legacy score  raw-string score")
for identity in base["rankings"][name]["full_order"]:
    print(f"{identity:30} {base['rankings'][name]['scores'][identity]:12} "
          f"{raw['rankings'][name]['scores'][identity]:17}")
print("\nLegacy selected:", " -> ".join(base["rankings"][name]["positive_order"]))
print("Opt-in selected:", " -> ".join(raw["rankings"][name]["positive_order"]))
print("\nFIXED REAL-CORPUS CLI EXAMPLE — interface/context demonstration only")
print("Query: cpu.stat.local; task cue: cgroupv2; limit: 1; context budget: 65536 bytes.")
for label, result in (("Legacy", base), ("Raw opt-in", raw)):
    diagnostic = result["fixed_real_corpus_cli_diagnostic"]
    output = diagnostic["output"]
    print(f"\n{label}: exit={diagnostic['exit_code']}; method={output['selection']['method']}")
    for item in output["items"]:
        print("  Selected:", item["ref"])
        print("  Revision:", item["revision"])
    print("  Context bytes:", output["context_bytes"])
    for context in output["contexts"]:
        for resource in context["resources"]:
            print("  Complete", resource["role"] + ":", resource["path"])
            print("    SHA-256:", resource["sha256"])
    print("  Context omissions:", output["context_omissions"])
print("\nDefault behavior is unchanged. No efficacy, latency or whole-Issue completion claim.")
