#!/usr/bin/env python3
"""One frozen CPU-only lexical-contract comparison; no task-quality inference."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import subprocess
import sys
import time
from contextlib import redirect_stdout
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path

RAW = "weighted-raw-string-v1"
LEGACY = "weighted-lexical-v1"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")


def git(checkout, *args):
    return subprocess.check_output(["git", "-C", str(checkout), *args])


def blob_hash(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def module_provenance(checkout):
    """Reject installed/preloaded modules outside the intended source checkout."""
    checkout = checkout.resolve()
    result = {}
    for name, module in sorted(sys.modules.items()):
        if name != "inferrsi" and not name.startswith("inferrsi."):
            continue
        source = Path(module.__file__).resolve()
        relative = source.relative_to(checkout).as_posix()
        assert relative.startswith("src/inferrsi/") and source.suffix == ".py", name
        data = source.read_bytes()
        expected = git(checkout, "show", f"HEAD:{relative}")
        assert data == expected, name
        result[name] = {"path": relative, "sha256": hashlib.sha256(data).hexdigest()}
    assert "inferrsi._skill_selection" in result
    return result


def verify_checkouts(args, manifest):
    result = {}
    for kind in ("baseline", "candidate"):
        checkout = args.baseline if kind == "baseline" else args.candidate
        sha = git(checkout, "rev-parse", "HEAD").decode().strip()
        tree = git(checkout, "rev-parse", "HEAD^{tree}").decode().strip()
        assert sha == manifest[kind + "_sha"], kind
        assert tree == manifest[kind + "_tree"], kind
        assert not git(checkout, "status", "--porcelain").strip(), kind
        for key, path in (
            ("corpus_git_tree", "src/inferrsi/data"),
            ("skill_library_git_tree", "src/inferrsi/data/skill_library"),
        ):
            assert git(checkout, "rev-parse", "HEAD:" + path).decode().strip() == manifest[key]
        sources = {}
        # Read exact source AND corpus bytes, rather than trusting clean stat/index metadata.
        for entry in git(checkout, "ls-tree", "-r", "-z", "HEAD", "src/inferrsi").split(b"\0"):
            if not entry:
                continue
            metadata, relative = entry.split(b"\t", 1)
            mode, kind_name, expected_blob = metadata.decode().split()
            path = relative.decode()
            assert kind_name == "blob" and mode in ("100644", "100755"), path
            source = checkout / path
            assert not source.is_symlink(), path
            data = source.read_bytes()
            assert blob_hash(data) == expected_blob, path
            sources[path] = hashlib.sha256(data).hexdigest()
        if kind == "candidate":
            for relative, expected in manifest["candidate_files"].items():
                assert digest(checkout / relative) == expected, relative
        result[kind] = {"commit": sha, "tree": tree, "clean": True, "source_sha256": sources}
    return result


def synthetic_reader(entries):
    from inferrsi.knowledge_operations import KnowledgeReader, _hash, _json

    registry_path = "data/skill_library/skill-index.json"
    registry = {"schema_version": 1, "skills": {}}
    library, records, mapping = {}, {}, {}
    for source_id, fields in entries.items():
        name = source_id.rsplit("/", 1)[-1].replace(".", "-")
        path = f"methods/{name}"
        prefix = f"data/skill_library/{path}/"
        registry["skills"][name] = {"path": path, "backend": "common"}
        library[prefix + "SKILL.md"] = fields.get("core", "").encode()
        for relative, text in fields.get("resources", {}).items():
            library[prefix + relative] = text.encode()
        identity = f"inferrsi.common.skills.{name.replace('-', '_')}"
        mapping["package:" + identity] = source_id
        tags, applicability = fields.get("tags_applicability", [[], {}])
        records[identity] = {
            "id": identity,
            "title": fields.get("title", ""),
            "summary": fields.get("summary", ""),
            "tags": tags,
            "applicability": applicability,
            "sources": [{"type": "internal", "issue": "test", "artifact": "synthetic"}],
            "status": "candidate",
            "verification": "synthetic-only",
            "repo": "inferrsi",
            "backend": "common",
            "scenario": "skills.discovery",
            "tier": "contribution",
            "index_type": "packaged-skill",
            "skill_documents": {"original": prefix + "SKILL.md"},
            "skill_metadata": {"name": name, "references": fields.get("references", [])},
        }
    library[registry_path] = _json(registry)
    for record in records.values():
        prefix = record["skill_documents"]["original"].removesuffix("SKILL.md")
        record["source_files"] = {
            "src/inferrsi/" + path: _hash(data)
            for path, data in library.items()
            if path.startswith(prefix) or path == registry_path
        }
    reader = KnowledgeReader()
    reader._records = records
    reader._library = (
        library,
        "sha256:" + _hash(_json({path: _hash(data) for path, data in sorted(library.items())})),
    )
    return reader, mapping


def observations(scorer, cue, fields):
    from inferrsi._skill_selection import words

    return {
        "tokens": sorted(words(cue)),
        "matches": {
            name: sorted(token for token in words(cue) if scorer(token, [(1, field["value"])]))
            for name, field in fields.items()
        },
        "per_field_scores": {
            name: scorer(cue, [(field["weight"], field["value"])]) for name, field in fields.items()
        },
        "score": scorer(cue, [(field["weight"], field["value"]) for field in fields.values()]),
    }


def compatibility(raw):
    from inferrsi._skill_selection import indexed_skill
    from inferrsi.knowledge_operations import _json

    reader, _ = synthetic_reader(
        {
            "a": {
                "title": "n",
                "summary": "Running",
                "core": "Core é\n",
                "references": ["refs.md"],
                "resources": {"refs.md": "Required", "LICENSE": "Legal", "a.md": "\n", "b.md": "n"},
            },
            "b": {"title": "n", "summary": "Running", "core": "Core é\n"},
        }
    )
    a, b = sorted(reader.records())
    bundle = reader.read(a)
    _, required, _ = indexed_skill(
        reader.records()[a], {**bundle.view(), "authority": "package"}, bundle.content
    )
    required_bytes = sum(len(bundle.content[path]) for path in required)
    matrix = {
        "ordinary": {},
        "ordinary_material": {"material": True},
        "ordinary_context": {"ids": [a], "context_bytes": 1000},
        "relevance": {"relevance": "n"},
        "relevance_limit": {"relevance": "n", "limit": 1},
        "query_and_substring": {"query": "synthetic run", "relevance": "n"},
        "query_no_match": {"query": "synthetic absent", "relevance": "n"},
        "kind_filter": {"kind": "skill", "relevance": "n"},
        "repo_filter": {"repo": "vllm", "relevance": "n"},
        "backend_filter": {"backend": "cpu", "relevance": "n"},
        "tier_filter": {"tier": "peer", "relevance": "n"},
        "scenario_filter": {"scenario": "diffusion.t2i", "relevance": "n"},
        "explicit_ids": {"ids": [b, a, "package:" + a], "relevance": "absent"},
        "exact_revision": {"ids": [a], "revisions": {a: bundle.revision}, "relevance": "n"},
        "wrong_revision": {"ids": [a], "revisions": {a: "sha256:" + "0" * 64}, "relevance": "n"},
        "item_exact_budget": {
            "ids": [a],
            "relevance": "n",
            "material": True,
            "max_bytes": len(_json(reader.collect(ids=[a], material=True)["items"][0])),
        },
        "item_tiny_budget": {"ids": [a], "relevance": "n", "max_bytes": 1},
    }
    for suffix, budget in (
        ("insufficient", required_bytes - 1),
        ("exact", required_bytes),
        ("optional_one", required_bytes + 1),
        ("optional_all", required_bytes + 2),
    ):
        matrix["context_" + suffix] = {"ids": [a], "relevance": "n", "context_bytes": budget}
    outputs = {}
    for name, options in matrix.items():
        kwargs = {**options}
        if raw and "relevance" in kwargs:
            kwargs["relevance_method"] = RAW
        outputs[name] = reader.collect(**kwargs)
    checks = {}
    for name in ("context_exact", "context_optional_one", "context_optional_all"):
        result = outputs[name]
        (context,) = result["contexts"]
        checks[name + "_required"] = [
            r["path"] for r in context["resources"][: len(required)]
        ] == required
        checks[name + "_revision"] = context["revision"] == bundle.revision
        checks[name + "_hashes"] = all(
            r["content"].encode() == reader.resource(a, r["path"], revision=context["revision"])
            and hashlib.sha256(r["content"].encode()).hexdigest() == r["sha256"]
            for r in context["resources"]
        )
    checks["optional_legacy_escape_admitted_first"] = outputs["context_optional_one"]["contexts"][
        0
    ]["resources"][-1]["path"].endswith("/a.md")
    checks["insufficient_omits_atomic_owner"] = (
        not outputs["context_insufficient"]["contexts"]
        and outputs["context_insufficient"]["context_omissions"][0]["reason"] == "context_limit"
    )
    checks["exact_budget_accounting"] = outputs["context_exact"]["context_bytes"] == required_bytes
    if raw:
        for name, options in {
            "unknown_method": {"relevance": "n", "relevance_method": "unknown"},
            "raw_without_cue": {"relevance_method": RAW},
            "empty_cue": {"relevance": "!!!", "relevance_method": RAW},
        }.items():
            try:
                reader.collect(**options)
            except ValueError:
                checks[name] = True
            else:
                checks[name] = False
    return {"outputs": outputs, "checks": checks}


def worker(args):
    sys.path.insert(0, str(args.checkout / "src"))
    from inferrsi import _skill_selection as selection

    initial_modules = module_provenance(args.checkout)
    fixtures = json.loads(args.fixtures.read_text())
    raw = args.mode == "candidate"
    scorer = selection.raw_string_lexical_score if raw else selection.lexical_score
    scalar = {
        case["id"]: observations(scorer, case["cue"], case["fields"]) for case in fixtures["cases"]
    }
    default_scalar = {
        case["id"]: observations(selection.lexical_score, case["cue"], case["fields"])
        for case in fixtures["cases"]
    }
    rankings = {}
    for fixture in fixtures["ranking_fixtures"]:
        reader, mapping = synthetic_reader(
            {r["qualifiedid"]: r["fields"] for r in fixture["records"]}
        )
        scores, field_results = {}, {}
        for record in fixture["records"]:
            fields = {
                name: {"weight": fixture["field_weights"][name], "value": value}
                for name, value in record["fields"].items()
            }
            field_results[record["qualifiedid"]] = observations(scorer, fixture["cue"], fields)
        for ref, source_id in mapping.items():
            record = reader.records()[ref.partition(":")[2]]
            bundle = reader.read(ref)
            core = bundle.content[record["skill_documents"]["original"]]
            kwargs = {"method": RAW} if raw else {}
            scores[source_id] = selection.skill_score(fixture["cue"], record, core, **kwargs)
        options = {"relevance_method": RAW} if raw else {}
        result = reader.collect(relevance=fixture["cue"], limit=len(scores), **options)
        rankings[fixture["id"]] = {
            "scores": scores,
            "fields": field_results,
            "full_order": sorted(scores, key=lambda name: (-scores[name], name)),
            "positive_order": [mapping[item["ref"]] for item in result["items"]],
            "omissions": result["omissions"],
        }
    result = {
        "mode": args.mode,
        "python": sys.version.split()[0],
        "scalar": scalar,
        "default_scalar": default_scalar,
        "rankings": rankings,
        "compatibility_default": compatibility(False),
    }
    if raw:
        result["compatibility_raw"] = compatibility(True)
    # Prospectively fixed interface diagnostic, not an additional acceptance/quality gate.
    from inferrsi.cli import main as cli_main

    diagnostic_args = [
        "collect",
        "cpu.stat.local",
        "--relevance",
        "cgroupv2",
        "--limit",
        "1",
        "--context-bytes",
        "65536",
        "--json",
    ]
    if raw:
        diagnostic_args += ["--relevance-method", RAW]
    capture = StringIO()
    with redirect_stdout(capture):
        exit_code = cli_main(diagnostic_args)
    result["fixed_real_corpus_cli_diagnostic"] = {
        "arguments": diagnostic_args,
        "exit_code": exit_code,
        "output": json.loads(capture.getvalue()),
        "scope": "interface/resource demonstration only, not task-quality or performance evidence",
    }
    result["module_provenance_before_scoring"] = initial_modules
    result["module_provenance_after_scoring"] = module_provenance(args.checkout)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


def assess(fixtures, baseline, candidate):
    failures, legacy_mismatches, corrected = [], [], []
    true_positive_total = 0
    true_positive_retained = 0
    nonstring_controls = 0
    for case in fixtures["cases"]:
        cid = case["id"]
        b, c = baseline["scalar"][cid], candidate["scalar"][cid]
        expected = {
            name: sorted(tokens) for name, tokens in case["expected_per_field_matches"].items()
        }
        expected_scores = {
            name: len(expected[name]) * field["weight"] for name, field in case["fields"].items()
        }
        if (
            c["matches"] != expected
            or c["score"] != case["expected_score"]
            or c["tokens"] != sorted(case["expected_distinct_tokens"])
            or c["per_field_scores"] != expected_scores
        ):
            failures.append("scalar:" + cid)
        for name, field in case["fields"].items():
            extra = sorted(set(b["matches"][name]) - set(expected[name]))
            missing = sorted(set(expected[name]) - set(b["matches"][name]))
            true_positive_total += len(expected[name])
            true_positive_retained += len(set(expected[name]) & set(c["matches"][name]))
            if extra or missing or b["per_field_scores"][name] != expected_scores[name]:
                legacy_mismatches.append(
                    {
                        "case": cid,
                        "field": name,
                        "false_positive": extra,
                        "false_negative": missing,
                        "weight_error": (
                            b["per_field_scores"][name] != field["weight"] * len(b["matches"][name])
                        ),
                    }
                )
            if (
                extra
                and isinstance(field["value"], str)
                and not set(extra) & set(c["matches"][name])
            ):
                corrected.append(
                    {
                        "case": cid,
                        "field": name,
                        "tokens": extra,
                        "removed_weighted_contribution": len(extra) * field["weight"],
                    }
                )
            if not isinstance(field["value"], str):
                nonstring_controls += 1
                if (
                    b["matches"][name] != c["matches"][name]
                    or b["per_field_scores"][name] != c["per_field_scores"][name]
                ):
                    failures.append("nonstring:" + cid + ":" + name)
    for fixture in fixtures["ranking_fixtures"]:
        result = candidate["rankings"][fixture["id"]]
        if (
            result["full_order"] != fixture["expected_order"]
            or result["positive_order"] != fixture["expected_positive_order"]
            or result["omissions"]
        ):
            failures.append("ranking:" + fixture["id"])
        for record in fixture["records"]:
            name = record["qualifiedid"]
            expected = {
                field: sorted(tokens)
                for field, tokens in record["expected_per_field_matches"].items()
            }
            obs = result["fields"][name]
            expected_field_scores = {
                field: len(tokens) * fixture["field_weights"][field]
                for field, tokens in expected.items()
            }
            if (
                result["scores"][name] != record["expected_score"]
                or obs["matches"] != expected
                or obs["score"] != record["expected_score"]
                or obs["per_field_scores"] != expected_field_scores
                or obs["tokens"] != sorted(fixture["expected_distinct_tokens"])
            ):
                failures.append("ranking_record:" + fixture["id"] + ":" + name)
    if baseline["default_scalar"] != candidate["default_scalar"]:
        failures.append("default_scalar_changed")
    bcompat, ccompat = baseline["compatibility_default"], candidate["compatibility_default"]
    if bcompat != ccompat:
        failures.append("default_output_changed")
    rawcompat = copy.deepcopy(candidate["compatibility_raw"])
    for name, result in rawcompat["outputs"].items():
        if "selection" in result:
            result["selection"]["method"] = LEGACY
        if result != bcompat["outputs"][name]:
            failures.append("raw_compatibility:" + name)
    for group in (bcompat, ccompat, rawcompat):
        failures.extend(
            "compatibility_check:" + name for name, passed in group["checks"].items() if not passed
        )
    if not corrected:
        failures.append("no_serialization_false_positive_corrected")
    if true_positive_total != true_positive_retained:
        failures.append("true_hit_lost")
    return {
        "verdict": "FAIL" if failures else "PASS",
        "failures": failures,
        "scope": (
            "synthetic/adversarial lexical-presence contract only; not general task accuracy, "
            "efficacy, latency, default promotion or issue closure"
        ),
        "scalar_cases": len(fixtures["cases"]),
        "ranking_fixtures": len(fixtures["ranking_fixtures"]),
        "legacy_mismatches": legacy_mismatches,
        "corrected_false_positive_contributions": corrected,
        "expected_positive_field_token_controls": true_positive_total,
        "retained_positive_field_token_controls": true_positive_retained,
        "nonstring_field_controls": nonstring_controls,
        "compatibility_requests": len(bcompat["outputs"]),
        "optional_resources_byte_identical": all(
            rawcompat["outputs"][name] == bcompat["outputs"][name]
            for name in bcompat["outputs"]
            if name.startswith("context_")
        ),
    }


def main(args):
    root = args.root.resolve()
    manifest_path = root / "plan/freeze.json"
    manifest = json.loads(manifest_path.read_text())
    review = json.loads((root / "plan/static-review.json").read_text())
    assert review["decision"] == "clear_for_one_frozen_comparison"
    assert review["candidate_sha"] == manifest["candidate_sha"]
    assert review["runner_sha256"] == digest(Path(__file__)) == manifest["runner_sha256"]
    for relative, expected in manifest["inputs"].items():
        assert digest(root / relative) == expected, relative
    before = verify_checkouts(args, manifest)
    frozen_manifest_hash = digest(manifest_path)
    frozen_review_hash = digest(root / "plan/static-review.json")
    # An exclusive start record prevents silently repeating a failed/partial comparison.
    write_json(
        root / "results/study-start.json",
        {
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
            "freeze_sha256": frozen_manifest_hash,
            "static_review_sha256": frozen_review_hash,
        },
    )
    write_json(root / "results/source-before.json", before)
    started = time.monotonic()
    try:
        outputs = {}
        for kind in ("baseline", "candidate"):
            command = [
                sys.executable,
                str(Path(__file__).resolve()),
                "--worker",
                "--mode",
                kind,
                "--checkout",
                str((args.baseline if kind == "baseline" else args.candidate).resolve()),
                "--fixtures",
                str(root / "validator/synthetic-lexical-contract-v1.json"),
            ]
            try:
                result = subprocess.run(command, text=True, capture_output=True, timeout=120)
            except subprocess.TimeoutExpired as exc:
                for suffix, captured in (("stdout.json", exc.stdout), ("stderr.txt", exc.stderr)):
                    data = captured or b""
                    if isinstance(data, str):
                        data = data.encode("utf-8")
                    (root / f"results/{kind}.{suffix}").write_bytes(data)
                raise RuntimeError(
                    f"{kind} worker timed out; partial stdout/stderr preserved"
                ) from exc
            (root / f"results/{kind}.stdout.json").write_text(result.stdout)
            (root / f"results/{kind}.stderr.txt").write_text(result.stderr)
            if result.returncode:
                raise RuntimeError(
                    f"{kind} worker exit {result.returncode}; preserved stdout/stderr"
                )
            outputs[kind] = json.loads(result.stdout)
        fixtures = json.loads((root / "validator/synthetic-lexical-contract-v1.json").read_text())
        verdict = assess(fixtures, outputs["baseline"], outputs["candidate"])
    except Exception as exc:
        verdict = {"verdict": "INCONCLUSIVE", "error": str(exc), "no_automatic_retry": True}
    try:
        assert digest(manifest_path) == frozen_manifest_hash
        assert digest(root / "plan/static-review.json") == frozen_review_hash
        assert digest(Path(__file__)) == manifest["runner_sha256"]
        for relative, expected in manifest["inputs"].items():
            assert digest(root / relative) == expected, relative
        after = verify_checkouts(args, manifest)
        write_json(root / "results/source-after.json", after)
        assert after == before, "source snapshots changed during comparison"
    except Exception as exc:
        verdict = {
            "verdict": "INCONCLUSIVE",
            "integrity_error": str(exc),
            "comparison_result_before_integrity_check": verdict,
            "no_automatic_retry": True,
        }
    verdict["diagnostic_execution_seconds_not_performance_evidence"] = time.monotonic() - started
    verdict["baseline_sha"] = manifest["baseline_sha"]
    verdict["candidate_sha"] = manifest["candidate_sha"]
    verdict["runner_sha256"] = manifest["runner_sha256"]
    write_json(root / "results/verdict.json", verdict)
    print(json.dumps(verdict, ensure_ascii=False, indent=2))
    return 0 if verdict["verdict"] == "PASS" else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--mode", choices=("baseline", "candidate"))
    parser.add_argument("--checkout", type=Path)
    parser.add_argument("--fixtures", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--candidate", type=Path)
    arguments = parser.parse_args()
    if arguments.worker:
        worker(arguments)
    else:
        raise SystemExit(main(arguments))
