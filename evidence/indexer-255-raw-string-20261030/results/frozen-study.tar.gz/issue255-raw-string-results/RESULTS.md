# Result: raw-string lexical contract, opt-in only

**Single frozen comparison: PASS for the declared synthetic lexical contract.**
This is not general retrieval accuracy, task efficacy, performance, default
promotion or whole-Issue #255 completion.

## What changed

New explicit `weighted-raw-string-v1` owner-ranking method matches original
string values. It retains substring/casefold matching, distinct cue words,
4/3/2/1 field weights, combined nonstring tags/applicability JSON behavior,
positive-score admission and identity ties. Legacy/default collection,
explicit-ID membership/order, query/filter semantics, item/context budgets,
mandatory resources and optional-resource scoring are preserved.

The source change is six files, including ordinary tests and API documentation.
No corpus, generated index, skill metadata or skill text changed.

## Frozen identities

- Baseline: `1052925ff22f9a850cebc64afd0083b35ed1fae9`
- Candidate: `728984c524cf696d063ff7ef0688ae126c8546a6`
- Candidate local branch: `experiment/issue255-raw-string-v1`
- Runner SHA-256: `7abe02af59ae06a5f2e7956d5236573172810b84025223714ded593c1e6c8061`
- Protocol SHA-256: `a91c63b85b3e168c06a4fb2986b92256a14679406b955baa6853e743712c3dfc`
- Fixture SHA-256: `70086b95ba74c182cb195c32d71fed7aed747bec975079160f10bf8fff673e18`
- Executed freeze SHA-256: `7bbf1f43644f62a625504b47b1797217453db3b0d9f1e3371245c901ad73d982`

## Contract result

| Gate/control | Retained result |
|---|---|
| Independently authored scalar cases | 14/14 exact token, per-field score and total labels |
| Independently authored ordering fixtures | 2/2 complete and positive-admission orders; 12/12 record labels |
| Serialization false positives | 5 field-token contributions removed across 2 scalar cases |
| Original-string positive controls | 15/15 retained |
| Expected nonstring-JSON positive controls | 11/11 retained across 6 nonstring field controls |
| Compatibility matrix | 21 fixed requests preserved; only selected method metadata differs where requested |
| Optional contexts for identical owners | Exact content, hashes, revisions, selection and omissions unchanged |
| Source/module identity | Before/after tracked source/corpus byte checks equal; 35 loaded module path/hash records per worker |

The removed contributions are `n`, `r`, `t` from an actual control-character title
(weighted excess 12), and `n`, `r` from a mixed literal/control summary (weighted
excess 6). Legacy has no false-negative or weight-arithmetic error on these cases;
the discrepancy is serialization-created substring presence.

## Human-readable capability demonstration

Synthetic cue `n t`:

| Synthetic title | Legacy score | Opt-in score |
|---|---:|---:|
| Actual newline + tab | 8 | 0 |
| Literal backslash-n + backslash-t | 8 | 8 |

The false-positive owner is no longer selected; the literal true hit and the
other genuine ordered controls remain. `results/readable-demo.txt` shows the
complete before/after ranking.

The prospectively fixed real-corpus interface example is:

```bash
# From issue255-raw-string-candidate, using the existing local test interpreter:
PYTHONPATH=src ../issue255-venv/bin/python -m inferrsi collect 'cpu.stat.local' \
  --relevance cgroupv2 --relevance-method weighted-raw-string-v1 \
  --context-bytes 65536 --limit 1 --json
```

Both modes selected `package:inferrsi.common.skills.cgroup_resource_controls`,
returned the same exact owner revision and complete 7,348-byte canonical SKILL.md
context, with no context omissions. This shows usable cue→skill/context behavior,
not a real-query quality improvement. Omit `--relevance-method` for legacy.

To display retained results without rerunning scoring, from this evidence root:

```bash
python validator/show_demo.py results
```

## Ordinary software checks and boundaries

- Full CPU suite: **2707 passed, 12 skipped, 284 subtests passed**, one existing
  duplicate-ZIP warning; Python 3.12.14.
- Focused selection/reader/store suite: 108 passed, 2 skipped.
- Ruff and diff whitespace checks passed; candidate worktree remains clean.
- Python 3.10/3.11 CI and a clean installed-wheel check were not run locally;
  required build packages are absent from this test venv.
- One ordinary development test initially expected a return code where the
  existing CLI raises SystemExit. Its assertion was fixed before candidate
  freeze; runtime implementation and frozen fixtures were not changed in
  response to any study outcome. The event remains in development-attempts.json.
- Independent static review required runner provenance/timeout preservation
  improvements before execution. The first freeze is retained; only the runner
  was revised/refrozen, never the candidate or labels. No scoring preceded
  clearance and no comparison was repeated.
- No latency claim is made from diagnostic duration/output bytes.
- No remote writes, PR, merge, paid/API/model/hardware experiment or historical
  PR #270 authorship certification occurred.
- Current-main integration and publication are separate work. This frozen
  historical baseline was not silently replaced after main advanced.

## Independent result audit

The independent reviewer inspected the retained output, frozen labels, source
snapshots and module proofs without rescoring. The audit passed;
`results/independent-postrun-review.json` carries the exact review scope and
hashes. Its supplementary saved-output audit script is explicitly **post-run**,
not the frozen production scorer and not a new acceptance gate.

`plan/current-head-knowledge-declaration.json` covers candidate 728984c5 only.
`plan/evidence-authorship.json` separates this new configured author from the
preexisting protocol/fixture authors and independent reviewer; unknown historical
configurations remain unknown. Refresh the current-head declaration after any
integration commit.
