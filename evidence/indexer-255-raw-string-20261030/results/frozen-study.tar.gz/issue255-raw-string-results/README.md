# Issue #255: opt-in raw-string lexical contract

Local-only candidate: `728984c524cf696d063ff7ef0688ae126c8546a6`.
Frozen baseline: `1052925ff22f9a850cebc64afd0083b35ed1fae9`.
No remote writes or paid/model/hardware experiments. No old sealed heldout use.

## Runnable interface

From the candidate checkout, using a Python interpreter with the repository dependencies:

```bash
PYTHONPATH=src python -m inferrsi collect 'cpu.stat.local' \
  --relevance cgroupv2 --relevance-method weighted-raw-string-v1 \
  --context-bytes 65536 --limit 1 --json
```

Omit `--relevance-method` for unchanged legacy behavior. The query remains a
filter; `--relevance` supplies the task cue; the explicitly selected method ranks
packaged skill owners. Returned context files are whole resources with exact
revision and SHA-256, not executable instructions or a standalone export.

The command above is the prospectively frozen real-corpus **interface example**.
It is not a heldout query or a general retrieval-quality/latency evaluation.
`plan/interface-diagnostic.json` records its exact scope before execution.

## Readable before/after demonstration

Once the one bounded study has produced outputs, render the retained data:

```bash
python validator/show_demo.py results
```

This renderer does not import either candidate or baseline and does not rerun
scoring. It separates a synthetic/adversarial newline-versus-literal-escape
example from the fixed real-corpus CLI example.

## Evidence and limitations

- `plan/`: unchanged original protocol/acceptance receipt/review; new-work
  configuration provenance, fixed interface diagnostic, hash freeze and required
  independent static review.
- `patch/candidate.diff`: exact committed candidate patch against the baseline.
- `validator/`: untouched independently authored 14 scalar + 2 ordering fixtures,
  one frozen comparison runner, and a read-only demo renderer.
- `results/`: ordinary development/check logs, one-run start receipt, full
  baseline/candidate outputs, explicit verdict, and readable demo.

The old acceptance receipt remains unchanged historical evidence of a prior
configuration block. New-work provenance is recorded separately. No historical
PR authorship is retrospectively certified.

Passing these adversarial fixtures establishes only the stated lexical-presence
contract. It cannot establish natural-language task success, broad retrieval
accuracy, model/hardware efficacy, latency improvement, default promotion or
whole-Issue completion. Historical v2/v3 outcomes remain separate and untouched.

Local verification uses Python 3.12.14. Repository CI's Python 3.10/3.11 matrix
and clean-wheel installation are not established by these local checks. Build
packages (`build`, `setuptools`, `wheel`) are absent in the existing test venv;
no package download or alternate installation was attempted.
