"""EP=2 dropless BF16 MoE, grouped local/shared experts and FP32 combine."""

import torch
import torch_npu
import torch.distributed as dist
import torch.nn.functional as F


_WEIGHT_CACHE = None


def _packed_weights(params):
    """Only parameter layouts are cached; retain identity and mutation versions."""
    global _WEIGHT_CACHE
    tensors = tuple(params[name] for name in (
        "expert_gate_up", "expert_down", "shared_gate_up", "shared_down"))
    try:
        versions = tuple(tensor._version for tensor in tensors)
    except RuntimeError:
        # Tensors without version counters cannot safely reuse a packed copy.
        versions = None
    if versions is not None and _WEIGHT_CACHE is not None:
        previous, previous_versions, packed = _WEIGHT_CACHE
        if all(old is new for old, new in zip(previous, tensors)) and versions == previous_versions:
            return packed
    gate_up = torch.cat((tensors[0], tensors[2].unsqueeze(0)), dim=0).transpose(1, 2)
    down = torch.cat((tensors[1], tensors[3].unsqueeze(0)), dim=0).transpose(1, 2)
    packed = (gate_up, down)
    _WEIGHT_CACHE = (tensors, versions, packed) if versions is not None else None
    return packed


def compute(x, params, *, config, group):
    world_size, rank = dist.get_world_size(group), dist.get_rank(group)
    if world_size != 2 or rank != config["rank"]:
        raise ValueError("Expected the configured two-rank process group")
    max_tokens = max(config["rank_tokens"])
    hidden = config["hidden"]
    padded_x = F.pad(x, (0, 0, 0, max_tokens - x.shape[0]))
    all_x = torch.empty((2 * max_tokens, hidden), dtype=x.dtype, device=x.device)
    gathering = dist.all_gather_into_tensor(all_x, padded_x.contiguous(), group=group, async_op=True)
    gate_up, down = _packed_weights(params)
    gathering.wait()
    all_logits = F.linear(all_x.float(), params["router_weight"], params["router_bias"])
    selected_logits, selected_experts = all_logits.topk(config["top_k"], dim=-1, sorted=True)
    probabilities = selected_logits.softmax(dim=-1)
    # Padded slots have zero weight; zero token rows make no contribution.
    for source_rank, count in enumerate(config["rank_tokens"]):
        if count < max_tokens:
            probabilities[source_rank * max_tokens + count:(source_rank + 1) * max_tokens] = 0
    local_contribution = torch.zeros((2 * max_tokens, hidden), dtype=torch.float32, device=x.device)
    dispatched, inverse_positions, groups, _ = torch_npu.npu_moe_init_routing_v2(
        all_x, selected_experts.to(torch.int32), expert_num=8,
        active_num=-1, drop_pad_mode=0, expert_tokens_num_type=0,
        expert_tokens_num_flag=True, quant_mode=-1,
        active_expert_range=[rank * 4, (rank + 1) * 4], row_idx_type=0)
    local_count = int(groups[-1].item())
    if local_count + x.shape[0]:
        # The fifth group computes the replicated shared expert on local tokens only.
        dispatched = torch.cat((dispatched[:local_count], x), dim=0)
        groups = torch.cat((groups, groups[-1:] + x.shape[0]), dim=0)
        projected = torch_npu.npu_grouped_matmul(
            [dispatched], [gate_up],
            group_list=groups, split_item=3, group_type=0)[0]
        activated = torch_npu.npu_swiglu(projected, dim=-1)
        values = torch_npu.npu_grouped_matmul(
            [activated], [down],
            group_list=groups, split_item=3, group_type=0)[0]
        if local_count:
            # The fusion API requires a full expanded buffer and nonnegative indices.
            expanded = F.pad(values[:local_count].float(), (0, 0, 0, selected_experts.numel() - local_count))
            scales = probabilities * (inverse_positions >= 0).reshape_as(probabilities)
            local_contribution = torch_npu.npu_moe_finalize_routing(
                expanded, None, None, None, scales, inverse_positions.clamp_min(0),
                None, drop_pad_mode=2)
        if x.shape[0]:
            start = rank * max_tokens
            local_contribution[start:start + x.shape[0]].add_(values[local_count:].float())
    local_routed = torch.empty((max_tokens, hidden), dtype=torch.float32, device=x.device)
    dist.reduce_scatter_tensor(local_routed, local_contribution, group=group)
    return local_routed[:x.shape[0]].to(dtype=x.dtype)
