"""EP=2 MoE + shared expert: AllGather/local experts/ReduceScatter baseline.

This is a self-contained, newly written implementation of the common
AllGather-based expert-parallel MoE workload architecture, not a copy of the
vLLM serving stack. It uses a fused gate/up projection and NPU SwiGLU.
"""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _mlp(x, gate_up, down):
    if x.shape[0] == 0:
        return x.new_empty((0, down.shape[0]))
    projected = F.linear(x, gate_up)
    if x.device.type == "npu":
        import torch_npu
        activated = torch_npu.npu_swiglu(projected, dim=-1)
    else:
        gate, up = projected.chunk(2, dim=-1)
        activated = F.silu(gate) * up
    return F.linear(activated, down)


def compute(x, params, *, config, group):
    world_size, rank = dist.get_world_size(group), dist.get_rank(group)
    if world_size != 2 or rank != config["rank"]:
        raise ValueError("Expected the configured two-rank process group")
    max_tokens = max(config["rank_tokens"])
    hidden = config["hidden"]
    padded_x = F.pad(x, (0, 0, 0, max_tokens - x.shape[0]))
    all_x = torch.empty((2 * max_tokens, hidden), dtype=x.dtype, device=x.device)
    dist.all_gather_into_tensor(all_x, padded_x.contiguous(), group=group)
    # The router is replicated: recompute the small FP32 projection after
    # gathering BF16 activations and avoid a separate logits collective.
    all_logits = F.linear(all_x.float(), params["router_weight"], params["router_bias"])
    selected_logits, selected_experts = all_logits.topk(config["top_k"], dim=-1, sorted=True)
    probabilities = selected_logits.softmax(dim=-1)
    # Padded slots have zero weight and never perform an expert MLP.
    for source_rank, count in enumerate(config["rank_tokens"]):
        if count < max_tokens:
            probabilities[source_rank * max_tokens + count:(source_rank + 1) * max_tokens] = 0
    local_contribution = torch.zeros((2 * max_tokens, hidden), dtype=torch.float32, device=x.device)
    import torch_npu
    positions = torch.nonzero(
        (selected_experts >= rank * 4) & (selected_experts < rank * 4 + 4)
        & (probabilities > 0), as_tuple=False
    )
    expert_ids = selected_experts[positions[:, 0], positions[:, 1]] - rank * 4
    order = torch.argsort(expert_ids)
    positions = positions.index_select(0, order)
    expert_ids = expert_ids.index_select(0, order)
    token_ids, slot_ids = positions[:, 0], positions[:, 1]
    routed_count = positions.shape[0]
    group_counts = (expert_ids.unsqueeze(1) == torch.arange(4, device=x.device)).sum(0)
    # The fifth group evaluates the replicated shared expert on local tokens.
    group_counts = torch.cat((group_counts, torch.tensor([x.shape[0]], dtype=torch.int64, device=x.device)))
    grouped_x = torch.cat((all_x.index_select(0, token_ids), x), dim=0)
    if grouped_x.shape[0]:
        gate_weights = [w.t() for w in params["expert_gate_up"].unbind(0)] + [params["shared_gate_up"].t()]
        down_weights = [w.t() for w in params["expert_down"].unbind(0)] + [params["shared_down"].t()]
        projected = torch_npu.npu_grouped_matmul(
            [grouped_x], gate_weights, group_list=group_counts,
            split_item=2, group_type=0, group_list_type=1
        )[0]
        activated = torch_npu.npu_swiglu(projected, dim=-1)
        values = torch_npu.npu_grouped_matmul(
            [activated], down_weights, group_list=group_counts,
            split_item=2, group_type=0, group_list_type=1
        )[0]
        shared = values[routed_count:]
        if routed_count:
            weighted = values[:routed_count].float() * probabilities[token_ids, slot_ids].unsqueeze(-1)
            local_contribution.index_add_(0, token_ids, weighted)
    else:
        shared = x.new_empty((0, hidden))
    local_routed = torch.empty((max_tokens, hidden), dtype=torch.float32, device=x.device)
    dist.reduce_scatter_tensor(local_routed, local_contribution, group=group)
    return (local_routed[:x.shape[0]] + shared.float()).to(dtype=x.dtype)
