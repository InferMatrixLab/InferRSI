"""EP=2 MoE + shared expert: AllGather/local experts/ReduceScatter baseline.

This is a self-contained, newly written implementation of the common
AllGather-based expert-parallel MoE workload architecture, not a copy of the
vLLM serving stack. It uses a fused gate/up projection and NPU SwiGLU.
"""

import torch
import torch.distributed as dist
import torch.nn.functional as F


def _mlp(x, gate_up, down):
    if x.shape[0] == 0:
        return x.new_empty((0, down.shape[0]))
    projected = F.linear(x, gate_up)
    if x.device.type == "npu":
        import torch_npu
        activated = torch_npu.npu_swiglu(projected, dim=-1)
    else:
        gate, up = projected.chunk(2, dim=-1)
        activated = F.silu(gate) * up
    return F.linear(activated, down)


def compute(x, params, *, config, group):
    world_size, rank = dist.get_world_size(group), dist.get_rank(group)
    if world_size != 2 or rank != config["rank"]:
        raise ValueError("Expected the configured two-rank process group")
    max_tokens = max(config["rank_tokens"])
    hidden = config["hidden"]
    padded_x = F.pad(x, (0, 0, 0, max_tokens - x.shape[0]))
    all_x = torch.empty((2 * max_tokens, hidden), dtype=x.dtype, device=x.device)
    gather = dist.all_gather_into_tensor(all_x, padded_x.contiguous(), group=group, async_op=True)
    shared = _mlp(x, params["shared_gate_up"], params["shared_down"])
    gather.wait()
    all_logits = F.linear(all_x.float(), params["router_weight"], params["router_bias"])
    selected_logits, selected_experts = all_logits.topk(config["top_k"], dim=-1, sorted=True)
    probabilities = selected_logits.softmax(dim=-1)
    # Padded slots have zero weight and never perform an expert MLP.
    for source_rank, count in enumerate(config["rank_tokens"]):
        if count < max_tokens:
            probabilities[source_rank * max_tokens + count:(source_rank + 1) * max_tokens] = 0
    local_contribution = torch.zeros((2 * max_tokens, hidden), dtype=torch.float32, device=x.device)
    import torch_npu
    flat_experts = selected_experts.flatten()
    flat_probs = probabilities.flatten()
    positions = torch.nonzero(
        (flat_experts >= rank * 4) & (flat_experts < rank * 4 + 4) & (flat_probs > 0),
        as_tuple=False,
    ).flatten()
    if positions.numel():
        local_ids = flat_experts.index_select(0, positions) - rank * 4
        order = local_ids.argsort()
        positions = positions.index_select(0, order)
        local_ids = local_ids.index_select(0, order)
        boundaries = (local_ids[:, None] <= torch.arange(4, device=x.device)[None, :]).sum(0)
        token_ids = torch.div(positions, config["top_k"], rounding_mode="floor")
        packed = all_x.index_select(0, token_ids)
        projected = torch_npu.npu_grouped_matmul(
            [packed], [params["expert_gate_up"].transpose(1, 2)],
            group_list=boundaries, split_item=2, group_type=0, group_list_type=0,
        )[0]
        activated = torch_npu.npu_swiglu(projected, dim=-1)
        values = torch_npu.npu_grouped_matmul(
            [activated], [params["expert_down"].transpose(1, 2)],
            group_list=boundaries, split_item=2, group_type=0, group_list_type=0,
        )[0]
        weighted = values.float() * flat_probs.index_select(0, positions).unsqueeze(-1)
        local_contribution.index_add_(0, token_ids, weighted)
    local_routed = torch.empty((max_tokens, hidden), dtype=torch.float32, device=x.device)
    dist.reduce_scatter_tensor(local_routed, local_contribution, group=group)
    return (local_routed[:x.shape[0]] + shared.float()).to(dtype=x.dtype)
